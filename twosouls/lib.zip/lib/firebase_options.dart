// ---------------------------------------------------------------------------
// PLACEHOLDER — replace this entire file by running:
//
//   flutterfire configure --project=YOUR_FIREBASE_PROJECT_ID
//
// That command auto-generates the real version of this file with your
// actual project credentials. Do NOT commit real credentials to git.
// ---------------------------------------------------------------------------

import 'package:firebase_core/firebase_core.dart' show FirebaseOptions;
import 'package:flutter/foundation.dart' show defaultTargetPlatform, kIsWeb, TargetPlatform;

class DefaultFirebaseOptions {
  static FirebaseOptions get currentPlatform {
    if (kIsWeb) return web;
    switch (defaultTargetPlatform) {
      case TargetPlatform.android: return android;
      case TargetPlatform.iOS:     return ios;
      default: throw UnsupportedError('DefaultFirebaseOptions: unsupported platform');
    }
  }

  // ⚠️  THESE ARE PLACEHOLDER VALUES — replace with your real project config
  static const FirebaseOptions web = FirebaseOptions(
    apiKey:            'YOUR_API_KEY',
    appId:             'YOUR_APP_ID',
    messagingSenderId: 'YOUR_SENDER_ID',
    projectId:         'YOUR_PROJECT_ID',
    storageBucket:     'YOUR_PROJECT_ID.appspot.com',
  );

  static const FirebaseOptions android = FirebaseOptions(
    apiKey:            'YOUR_ANDROID_API_KEY',
    appId:             'YOUR_ANDROID_APP_ID',
    messagingSenderId: 'YOUR_SENDER_ID',
    projectId:         'YOUR_PROJECT_ID',
    storageBucket:     'YOUR_PROJECT_ID.appspot.com',
  );

  static const FirebaseOptions ios = FirebaseOptions(
    apiKey:            'YOUR_IOS_API_KEY',
    appId:             'YOUR_IOS_APP_ID',
    messagingSenderId: 'YOUR_SENDER_ID',
    projectId:         'YOUR_PROJECT_ID',
    storageBucket:     'YOUR_PROJECT_ID.appspot.com',
    iosClientId:       'YOUR_IOS_CLIENT_ID',
    iosBundleId:       'com.example.twosouls',
  );
}
